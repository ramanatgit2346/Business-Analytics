# RetailIQ — Retail Sales and Customer Behavior Analytics System

A full-stack MCA Business Analytics mini-project, using a **real SQL database** (SQLite), React, Express, and Recharts. It exports data for Excel Pivot Tables and Tableau dashboards.

## Prerequisites
- Node.js 20 or 22 LTS (recommended)
- npm
- Optional: Excel/LibreOffice Calc and Tableau Public/Desktop

## Run on Windows / macOS / Linux
```bash
npm install
npm run install:all
npm run seed
npm run dev
```
Open **http://localhost:5173**. API: **http://localhost:5000/api/health**.

Alternatively run `start-windows.cmd` on Windows (first run installs packages and seeds sample data if the DB does not exist).

The sample data is synthetic and deterministic (120 customers, 12 products, 850 orders). Running `npm run seed` **resets** all customer, product, and order records.

## Technology stack
- Frontend: React + Vite + Recharts + Lucide
- Backend: Node.js + Express + Zod validation
- Database: **SQLite relational SQL** via better-sqlite3, with foreign keys, constraints, indexes, joins, grouping, aggregates and transactions
- Excel: export `/api/export/orders.csv`, then create formulas and Pivot Tables
- Tableau: import the CSV export, build interactive worksheets and dashboards (instructions below)

## Database schema
- `customers(id, name, email, region, joined_at)`
- `products(id, name, category, price, cost, stock)`
- `orders(id, customer_id, order_date, status)`
- `order_items(id, order_id, product_id, quantity, unit_price, unit_cost)`

Relationships: Customer 1:N Orders; Orders 1:N OrderItems; Products 1:N OrderItems.

## Features
- Revenue, gross profit, orders, average order value KPIs
- Date, region and product-category filters
- Monthly revenue/profit, regional sales, category split
- Top products and top customers
- Mean, median, quartiles and IQR-based high outlier detection
- Customer creation, stock-aware order creation (single product per submission), customer directory and product inventory
- Export transaction-level CSV for Excel/Tableau
- Input validation, foreign keys and SQL parameter binding

## Tableau workflow
1. In the app click **Export CSV**.
2. Open Tableau, connect to **Text file** and select `retail_orders.csv`.
3. Exclude `Cancelled` rows for revenue reporting.
4. Create calculated fields:
   - `Revenue = [quantity] * [unit_price]`
   - `Gross Profit = [quantity] * ([unit_price] - [unit_cost])`
5. Build worksheets: revenue by month, revenue by category, revenue by region, top products.
6. Assemble a dashboard with date/region/category filters and KPI tiles.
7. Add a story explaining the highest-revenue category and strongest region.
Note: the app already exports `revenue`; avoid double-counting it if you also create the calculated field.

## Excel workflow
1. Open CSV, format dates and amounts, apply filters and conditional formatting.
2. Add a `Profit` column: `=H2*(I2-J2)` (check actual column positions).
3. Create Pivot Tables by category, region and month.
4. Use `SUMIF`, `AVERAGEIF`, `COUNTIF`, `IF`, and lookup functions.
5. Analyze transaction outliers using quartiles and IQR.

## Example SQL queries
See `sql/analytics.sql` for joins, grouping, subqueries, CTEs, customer inactivity, and outliers.

## API
- `GET /api/health`
- `GET /api/meta`
- `GET /api/dashboard?from=2025-01-01&to=2026-10-25&region=North&category=Electronics`
- `GET /api/customers?search=...`
- `POST /api/customers` body `{ "name":"Asha Singh","email":"asha@example.com","region":"North" }`
- `GET /api/products`
- `GET /api/orders`
- `POST /api/orders` body `{ "customerId":1,"orderDate":"2026-10-25","items":[{"productId":1,"quantity":1}] }`
- `GET /api/export/orders.csv`

## Scope and caveats
This is an academic/local demonstration, **not** a production multi-user commerce platform. It has no authentication, role management, payment processing or deployment hardening. Currency is INR. Profit means gross product margin only, excluding tax, shipping and overhead. Historical seeded transactions do not deduct current stock; new orders do. The dashboard's customer ranking is based on filtered sales. The customer directory and recent orders are not filtered by dashboard selections. For deployment, add authentication/authorization, backups, tests, audit logging and HTTPS.
