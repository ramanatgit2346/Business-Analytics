@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Please install Node.js 20 or 22 LTS first.& pause & exit /b 1)
if not exist "node_modules" call npm install || exit /b 1
if not exist "backend\node_modules" call npm install --prefix backend || exit /b 1
if not exist "frontend\node_modules" call npm install --prefix frontend || exit /b 1
if not exist "backend\data\retail.sqlite" call npm run seed --prefix backend || exit /b 1
echo Open http://localhost:5173 after the servers start.
call npm run dev
pause
