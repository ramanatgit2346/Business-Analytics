-- RetailIQ: Run these READ-ONLY queries in DB Browser for SQLite > Execute SQL.
-- Open backend/data/retail.sqlite. Refresh/reopen the database after website changes.

-- 1. SELECT: products added from website
SELECT id, name, category, price, cost, stock FROM products ORDER BY id DESC;

-- 2. SELECT: customers created or edited on website
SELECT id, name, email, region FROM customers ORDER BY id DESC;

-- 3. INNER JOIN: orders linked to customers
SELECT o.id AS order_id, o.order_date, c.name AS customer, o.status
FROM orders o INNER JOIN customers c ON c.id = o.customer_id
ORDER BY o.id DESC LIMIT 30;

-- 4. Multi-table JOIN: order details linked to products
SELECT o.id AS order_id, c.name AS customer, p.name AS product,
       oi.quantity, oi.unit_price, oi.quantity*oi.unit_price AS line_revenue
FROM orders o
JOIN customers c ON c.id=o.customer_id
JOIN order_items oi ON oi.order_id=o.id
JOIN products p ON p.id=oi.product_id
ORDER BY o.id DESC LIMIT 30;

-- 5. Aggregate functions, WHERE, GROUP BY, ORDER BY
SELECT p.category, COUNT(DISTINCT o.id) AS completed_orders,
       SUM(oi.quantity) AS units_sold,
       ROUND(SUM(oi.quantity*oi.unit_price),2) AS revenue
FROM products p JOIN order_items oi ON oi.product_id=p.id
JOIN orders o ON o.id=oi.order_id
WHERE o.status='Completed'
GROUP BY p.category ORDER BY revenue DESC;

-- 6. LEFT JOIN: customers with no orders
SELECT c.id,c.name FROM customers c
LEFT JOIN orders o ON o.customer_id=c.id
WHERE o.id IS NULL ORDER BY c.id;

-- 7. SUBQUERY: products priced above the average
SELECT id,name,price FROM products
WHERE price>(SELECT AVG(price) FROM products)
ORDER BY price DESC;

-- 8. Check table relationships / foreign keys
PRAGMA foreign_key_list('orders');
PRAGMA foreign_key_list('order_items');

-- 9. Check referential integrity
PRAGMA foreign_key_check;

-- 10. Check most recent orders and cancellations
SELECT id,customer_id,order_date,status FROM orders ORDER BY id DESC LIMIT 30;

-- 11. See schema definitions (DDL)
SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';
