-- RetailIQ: SQL examples for practical viva (SQLite syntax).
-- 1. Completed revenue and profit by category: JOIN + GROUP BY
SELECT p.category, ROUND(SUM(oi.quantity*oi.unit_price),2) revenue,
 ROUND(SUM(oi.quantity*(oi.unit_price-oi.unit_cost)),2) profit
FROM orders o
JOIN order_items oi ON oi.order_id=o.id
JOIN products p ON p.id=oi.product_id
WHERE o.status='Completed'
GROUP BY p.category ORDER BY revenue DESC;

-- 2. All customers, including those with zero orders: LEFT JOIN
SELECT c.id,c.name,COUNT(DISTINCT CASE WHEN o.status='Completed' THEN o.id END) completed_orders,
 ROUND(COALESCE(SUM(CASE WHEN o.status='Completed' THEN oi.quantity*oi.unit_price ELSE 0 END),0),2) spending
FROM customers c
LEFT JOIN orders o ON o.customer_id=c.id
LEFT JOIN order_items oi ON oi.order_id=o.id
GROUP BY c.id ORDER BY spending DESC;

-- 3. Customers without completed orders: correlated NOT EXISTS subquery
SELECT c.id,c.name,c.email FROM customers c
WHERE NOT EXISTS(SELECT 1 FROM orders o WHERE o.customer_id=c.id AND o.status='Completed');

-- 4. Monthly revenue
SELECT substr(o.order_date,1,7) month,ROUND(SUM(oi.quantity*oi.unit_price),2) revenue
FROM orders o JOIN order_items oi ON oi.order_id=o.id
WHERE o.status='Completed' GROUP BY month ORDER BY month;

-- 5. Products with above-average selling price: scalar subquery
SELECT name,price FROM products WHERE price>(SELECT AVG(price) FROM products);

-- 6. Stock threshold with CASE
SELECT name,stock,CASE WHEN stock<15 THEN 'Low stock' ELSE 'Available' END stock_status
FROM products ORDER BY stock;

-- 7. Outliers using NTILE approximation (quartiles in app use interpolated quantiles)
WITH totals AS (
 SELECT o.id,SUM(oi.quantity*oi.unit_price) amount
 FROM orders o JOIN order_items oi ON oi.order_id=o.id
 WHERE o.status='Completed' GROUP BY o.id
)
SELECT * FROM totals ORDER BY amount DESC LIMIT 10;
