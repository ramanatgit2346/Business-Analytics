# RetailIQ SQLite CRUD + DB Browser Demonstration

This edition retains the **original SQLite database** and React dashboard. It adds visible INSERT, SELECT, UPDATE, DELETE, joins, aggregation and transactions without requiring MySQL.

## Start (Windows PowerShell)

From `backend`:

```powershell
npm.cmd install
npm.cmd start
```

In a second terminal, from `frontend`:

```powershell
npm.cmd install
npm.cmd run dev
```

Visit http://localhost:5173. If the database is empty on a **fresh install only**, stop the backend and run `npm.cmd run seed` in backend before starting it again. **Warning: seeding deletes all existing records**. Do not seed your current working database unless you want to reset it.

## Locate your real database file

`retail-sales-analytics/backend/data/retail.sqlite`

It is created when the backend starts. It is deliberately **not included** in this source-code ZIP because your local database contains your own data. Copy your existing `backend/data/retail.sqlite` into the new backend's `data` folder (while both servers are stopped) if you want to retain your current data. If the original database is in WAL mode, stop the original backend cleanly before copying; copy the complete database backup, not a stale file while it is in use.

Open **DB Browser for SQLite > Open Database > backend/data/retail.sqlite**. In **Database Structure**, expand `customers`, `products`, `orders`, `order_items`. In **Browse Data**, select a table. In **Execute SQL**, paste queries from `sql/db_browser_demo.sql` and press Run.

To see a change: keep DB Browser open and click **Browse Data > Refresh**, or close and reopen the database if it is showing cached records. Avoid editing the same database from both tools simultaneously. Database changes performed by the website are committed automatically; no 'Write Changes' button is needed for website actions.

## Website button -> HTTP API -> actual SQLite SQL

| Website location / action | API endpoint | SQL concept / statement | Verify in DB Browser |
|---|---|---|---|
| Products > Add Product | `POST /api/products` | `INSERT INTO products (...) VALUES (...)` | Browse Data > products, sort by id |
| Products > Edit > Update Product | `PUT /api/products/:id` | `UPDATE products SET ... WHERE id=?` | Browse Data > products, inspect same id |
| Products > Delete | `DELETE /api/products/:id` | `DELETE FROM products WHERE id=?` | Browse Data > products; record disappears if not referenced |
| Products > list | `GET /api/products` | `SELECT * FROM products ORDER BY name` | Browse Data > products |
| Customers > Add Customer | `POST /api/customers` | `INSERT INTO customers (...) VALUES (...)` | Browse Data > customers |
| Customers > Edit | `PUT /api/customers/:id` | `UPDATE customers SET ... WHERE id=?` | Browse Data > customers |
| Customers > Delete | `DELETE /api/customers/:id` | `DELETE FROM customers WHERE id=?` | Browse Data > customers, only if no orders |
| Customers > directory | `GET /api/customers` | `LEFT JOIN`, `GROUP BY`, `COUNT`, `SUM`, `LIKE` | Run matching queries in Execute SQL |
| Orders > Place Order | `POST /api/orders` | **TRANSACTION**: `INSERT orders`, `INSERT order_items`, `UPDATE products SET stock=stock-?` | Browse Data > orders, order_items, products |
| Orders > Cancel order | `PATCH /api/orders/:id/cancel` | **TRANSACTION**: `UPDATE orders SET status='Cancelled'` and restore stock | Browse Data > orders and products |
| Orders > recent orders | `GET /api/orders` | `JOIN`, `GROUP BY`, `SUM`, `ORDER BY` | Execute SQL joins |
| Dashboard > charts | `GET /api/dashboard` | `JOIN`, `WHERE`, `GROUP BY`, `SUM`, `COUNT`, `ORDER BY` | Execute SQL aggregate queries |
| SQL Operations > Run SQL Queries | `GET /api/sql-demo` | `SELECT`, `COUNT`, `UNION ALL`, `JOIN`, `LEFT JOIN`, `GROUP BY`, `SUM` | Compare SQL Operations page to Execute SQL results |
| Export CSV | `GET /api/export/orders.csv` | `SELECT` with four-table `JOIN` | Open CSV in spreadsheet program |

## Primary and foreign key relationships

- `customers.id` (PK) -> `orders.customer_id` (FK): one customer to many orders.
- `orders.id` (PK) -> `order_items.order_id` (FK): one order to many line items.
- `products.id` (PK) -> `order_items.product_id` (FK): one product can appear in many order items.
- `PRAGMA foreign_keys = ON` is enabled in `backend/src/db.js`.
- Products and customers that have referenced order records cannot be deleted; SQLite raises a foreign-key constraint and the website displays an error. This is correct **referential integrity**.
- `order_items.order_id` uses `ON DELETE CASCADE` at the schema level, but this application preserves sales history and does not expose deleting orders.
- Product updates affect future orders, while old `order_items.unit_price` and `unit_cost` retain historical values.
- Cancelling an order restores product stock in the same transaction; completed-sales analytics exclude cancelled orders.

## Demo sequence for your MCA viva

1. Open `retail.sqlite` in DB Browser and show Database Structure and foreign keys.
2. Open RetailIQ website > Products > Add Product. Refresh `products` in DB Browser and show the new row (`INSERT`).
3. Edit that product's price and stock. Refresh the row (`UPDATE`).
4. Delete the new unused product. Refresh (`DELETE`).
5. Add a customer. Verify the row (`INSERT`), then edit their region (`UPDATE`).
6. Place an order for a product with sufficient stock. Show new rows in `orders` and `order_items`, and reduced `products.stock` (`TRANSACTION` + FK + UPDATE).
7. Cancel that order. Show `orders.status='Cancelled'` and restored product stock (`TRANSACTION` + UPDATE).
8. Open SQL Operations > Run SQL Queries. Compare results with the queries in `sql/db_browser_demo.sql` (`JOIN`, `GROUP BY`, `COUNT`, `SUM`, `LEFT JOIN`, `UNION ALL`, `SUBQUERY`).

## Notes

- Do **not** run `npm run seed` after entering your own data: it clears all tables.
- The new source ZIP does not contain your current local database. The website and DB Browser must point to the **same** `retail.sqlite` file to see identical records.
- SQLite is a genuine relational database; no MySQL Server or MySQL Workbench is required.
