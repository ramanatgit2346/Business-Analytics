import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import 'dotenv/config';
import {z} from 'zod';
import {db} from './db.js';
const app=express();
app.use(helmet());app.use(cors({origin:process.env.FRONTEND_ORIGIN||'http://localhost:5173'}));app.use(express.json({limit:'100kb'}));
const q=(sql,params=[])=>db.prepare(sql).all(...params);
const one=(sql,params=[])=>db.prepare(sql).get(...params);
const sales=`FROM orders o JOIN customers c ON c.id=o.customer_id JOIN order_items oi ON oi.order_id=o.id JOIN products p ON p.id=oi.product_id`;
const filters=(query,alias='o')=>{
 const clauses=[`${alias}.status='Completed'`],params=[];
 if(query.from){clauses.push(`${alias}.order_date >= ?`);params.push(query.from);}
 if(query.to){clauses.push(`${alias}.order_date <= ?`);params.push(query.to);}
 if(query.region){clauses.push('c.region = ?');params.push(query.region);}
 if(query.category){clauses.push('p.category = ?');params.push(query.category);}
 return {where:' WHERE '+clauses.join(' AND '),params};
};
const validDate=v=>!v||/^\d{4}-\d{2}-\d{2}$/.test(v);
app.get('/api/health',(_,res)=>res.json({ok:true}));
app.get('/api/meta',(_,res)=>res.json({regions:q('SELECT DISTINCT region FROM customers ORDER BY region').map(x=>x.region),categories:q('SELECT DISTINCT category FROM products ORDER BY category').map(x=>x.category)}));
app.get('/api/dashboard',(req,res,next)=>{try{
 if(!validDate(req.query.from)||!validDate(req.query.to))return res.status(400).json({error:'Invalid date format'});
 const f=filters(req.query);
 const summary=one(`SELECT ROUND(COALESCE(SUM(oi.quantity*oi.unit_price),0),2) revenue, ROUND(COALESCE(SUM(oi.quantity*(oi.unit_price-oi.unit_cost)),0),2) profit, COUNT(DISTINCT o.id) orders, COUNT(DISTINCT o.customer_id) activeCustomers, COALESCE(SUM(oi.quantity),0) units ${sales} ${f.where}`,f.params);
 const monthly=q(`SELECT substr(o.order_date,1,7) month,ROUND(SUM(oi.quantity*oi.unit_price),2) revenue,ROUND(SUM(oi.quantity*(oi.unit_price-oi.unit_cost)),2) profit ${sales} ${f.where} GROUP BY month ORDER BY month`,f.params);
 const categories=q(`SELECT p.category name,ROUND(SUM(oi.quantity*oi.unit_price),2) revenue ${sales} ${f.where} GROUP BY p.category ORDER BY revenue DESC`,f.params);
 const regions=q(`SELECT c.region name,ROUND(SUM(oi.quantity*oi.unit_price),2) revenue ${sales} ${f.where} GROUP BY c.region ORDER BY revenue DESC`,f.params);
 const products=q(`SELECT p.name, p.category, SUM(oi.quantity) units,ROUND(SUM(oi.quantity*oi.unit_price),2) revenue,ROUND(SUM(oi.quantity*(oi.unit_price-oi.unit_cost)),2) profit ${sales} ${f.where} GROUP BY p.id ORDER BY revenue DESC LIMIT 10`,f.params);
 const customers=q(`SELECT c.id,c.name,c.region,COUNT(DISTINCT o.id) orders,ROUND(SUM(oi.quantity*oi.unit_price),2) spending ${sales} ${f.where} GROUP BY c.id ORDER BY spending DESC LIMIT 10`,f.params);
 const values=q(`SELECT SUM(oi.quantity*oi.unit_price) amount ${sales} ${f.where} GROUP BY o.id ORDER BY amount`,f.params).map(x=>x.amount);
 const median=a=>a.length?(a.length%2?a[(a.length-1)/2]:(a[a.length/2-1]+a[a.length/2])/2):0;
 const quantile=(a,p)=>{if(!a.length)return 0;const idx=(a.length-1)*p,lo=Math.floor(idx),hi=Math.ceil(idx);return a[lo]+(a[hi]-a[lo])*(idx-lo);};
 const q1=quantile(values,.25),q3=quantile(values,.75),upper=q3+1.5*(q3-q1);
 const statistics={mean:values.length?values.reduce((a,b)=>a+b,0)/values.length:0,median:median(values),q1,q3,upperFence:upper,outliers:values.filter(v=>v>upper).length};
 res.json({summary:{...summary,aov:summary.orders?summary.revenue/summary.orders:0},monthly,categories,regions,products,customers,statistics});
 }catch(e){next(e)}});
app.get('/api/customers',(req,res,next)=>{try{
 const term=String(req.query.search||'').slice(0,80);
 const rows=q(`SELECT c.id,c.name,c.email,c.region,c.joined_at,COUNT(DISTINCT CASE WHEN o.status='Completed' THEN o.id END) orders,
 ROUND(COALESCE(SUM(CASE WHEN o.status='Completed' THEN oi.quantity*oi.unit_price ELSE 0 END),0),2) spending
 FROM customers c LEFT JOIN orders o ON o.customer_id=c.id LEFT JOIN order_items oi ON oi.order_id=o.id
 WHERE c.name LIKE ? OR c.email LIKE ? GROUP BY c.id ORDER BY spending DESC LIMIT 200`,[`%${term}%`,`%${term}%`]);
 res.json(rows);
 }catch(e){next(e)}});
app.get('/api/products',(_,res)=>res.json(q('SELECT * FROM products ORDER BY name')));
const customerSchema=z.object({name:z.string().trim().min(2).max(100),email:z.string().email().max(150),region:z.enum(['North','South','East','West'])});
// Relational CRUD operations: INSERT, UPDATE, DELETE, SELECT and FK checks.
const productSchema=z.object({name:z.string().trim().min(2).max(120),category:z.string().trim().min(2).max(60),price:z.number().finite().nonnegative(),cost:z.number().finite().nonnegative(),stock:z.number().int().nonnegative()});
const positiveId=z.coerce.number().int().positive();
app.post('/api/products',(req,res,next)=>{try{
 const p=productSchema.parse(req.body);
 const result=db.prepare('INSERT INTO products(name,category,price,cost,stock) VALUES(?,?,?,?,?)').run(p.name,p.category,p.price,p.cost,p.stock);
 res.status(201).json({id:Number(result.lastInsertRowid),...p});
 }catch(e){next(e)}});
app.put('/api/products/:id',(req,res,next)=>{try{
 const id=positiveId.parse(req.params.id),p=productSchema.parse(req.body);
 const result=db.prepare('UPDATE products SET name=?,category=?,price=?,cost=?,stock=? WHERE id=?').run(p.name,p.category,p.price,p.cost,p.stock,id);
 if(!result.changes)return res.status(404).json({error:'Product not found'});
 res.json({id,...p});
 }catch(e){next(e)}});
app.delete('/api/products/:id',(req,res,next)=>{try{
 const id=positiveId.parse(req.params.id);
 // Preserve sales history: an item referenced by an order cannot be deleted.
 const result=db.prepare('DELETE FROM products WHERE id=?').run(id);
 if(!result.changes)return res.status(404).json({error:'Product not found'});
 res.json({deleted:true,id});
 }catch(e){next(e)}});
app.put('/api/customers/:id',(req,res,next)=>{try{
 const id=positiveId.parse(req.params.id),c=customerSchema.parse(req.body);
 const result=db.prepare('UPDATE customers SET name=?,email=?,region=? WHERE id=?').run(c.name,c.email,c.region,id);
 if(!result.changes)return res.status(404).json({error:'Customer not found'});
 res.json({id,...c});
 }catch(e){next(e)}});
app.delete('/api/customers/:id',(req,res,next)=>{try{
 const id=positiveId.parse(req.params.id);
 const result=db.prepare('DELETE FROM customers WHERE id=?').run(id);
 if(!result.changes)return res.status(404).json({error:'Customer not found'});
 res.json({deleted:true,id});
 }catch(e){next(e)}});
app.patch('/api/orders/:id/cancel',(req,res,next)=>{try{
 const id=positiveId.parse(req.params.id);
 const result=db.transaction(()=>{
  const order=one('SELECT id,status FROM orders WHERE id=?',[id]);
  if(!order)throw Object.assign(new Error('Order not found'),{status:404});
  if(order.status==='Cancelled')throw new Error('Order already cancelled');
  const items=q('SELECT product_id,quantity FROM order_items WHERE order_id=?',[id]);
  for(const item of items)db.prepare('UPDATE products SET stock=stock+? WHERE id=?').run(item.quantity,item.product_id);
  db.prepare("UPDATE orders SET status='Cancelled' WHERE id=?").run(id);
  return {id,status:'Cancelled',stockRestored:true};
 })();res.json(result);
 }catch(e){next(e)}});
app.get('/api/sql-demo',(_,res,next)=>{try{
 res.json({tableCounts:q("SELECT 'customers' table_name,COUNT(*) records FROM customers UNION ALL SELECT 'products',COUNT(*) FROM products UNION ALL SELECT 'orders',COUNT(*) FROM orders UNION ALL SELECT 'order_items',COUNT(*) FROM order_items"),
  salesByCategory:q("SELECT p.category,COUNT(DISTINCT o.id) order_count,ROUND(SUM(oi.quantity*oi.unit_price),2) revenue FROM products p JOIN order_items oi ON oi.product_id=p.id JOIN orders o ON o.id=oi.order_id WHERE o.status='Completed' GROUP BY p.category ORDER BY revenue DESC"),
  customersWithoutOrders:q('SELECT c.id,c.name FROM customers c LEFT JOIN orders o ON o.customer_id=c.id WHERE o.id IS NULL ORDER BY c.id LIMIT 20')});
 }catch(e){next(e)}});
app.get('/api/orders',(req,res,next)=>{try{
 const limit=Math.min(100,Math.max(1,Number(req.query.limit)||50));
 res.json(q(`SELECT o.id,o.order_date,o.status,c.name customer,c.region,
 ROUND(SUM(oi.quantity*oi.unit_price),2) total FROM orders o JOIN customers c ON c.id=o.customer_id
 JOIN order_items oi ON oi.order_id=o.id GROUP BY o.id ORDER BY o.order_date DESC,o.id DESC LIMIT ?`,[limit]));
 }catch(e){next(e)}});
app.post('/api/customers',(req,res,next)=>{try{
 const data=customerSchema.parse(req.body);
 const r=db.prepare('INSERT INTO customers(name,email,region) VALUES(?,?,?)').run(data.name,data.email,data.region);
 res.status(201).json({id:r.lastInsertRowid,...data});
 }catch(e){next(e)}});
const orderSchema=z.object({customerId:z.number().int().positive(),orderDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),items:z.array(z.object({productId:z.number().int().positive(),quantity:z.number().int().positive().max(100)})).min(1).max(30)});
app.post('/api/orders',(req,res,next)=>{try{
 const data=orderSchema.parse(req.body);
 const result=db.transaction(()=>{
  if(!one('SELECT id FROM customers WHERE id=?',[data.customerId]))throw new Error('Customer not found');
  const id=db.prepare('INSERT INTO orders(customer_id,order_date,status) VALUES(?,?,?)').run(data.customerId,data.orderDate,'Completed').lastInsertRowid;
  for(const item of data.items){
   const p=one('SELECT * FROM products WHERE id=?',[item.productId]);
   if(!p)throw new Error('Product not found');
   if(p.stock<item.quantity)throw new Error(`Insufficient stock for ${p.name}`);
   db.prepare('INSERT INTO order_items(order_id,product_id,quantity,unit_price,unit_cost) VALUES(?,?,?,?,?)').run(id,p.id,item.quantity,p.price,p.cost);
   db.prepare('UPDATE products SET stock=stock-? WHERE id=?').run(item.quantity,p.id);
  }return id;
 })();
 res.status(201).json({id:result});
 }catch(e){next(e)}});
app.get('/api/export/orders.csv',(_,res)=>{
 const rows=q(`SELECT o.id,o.order_date,o.status,c.name customer,c.region,p.name product,p.category,oi.quantity,oi.unit_price,oi.unit_cost,(oi.quantity*oi.unit_price) revenue FROM orders o JOIN customers c ON c.id=o.customer_id JOIN order_items oi ON oi.order_id=o.id JOIN products p ON p.id=oi.product_id ORDER BY o.id`);
 const cols=['id','order_date','status','customer','region','product','category','quantity','unit_price','unit_cost','revenue'];
 const esc=v=>'"'+String(v??'').replaceAll('"','""')+'"';
 res.type('text/csv').set('Content-Disposition','attachment; filename="retail_orders.csv"').send([cols.join(','),...rows.map(r=>cols.map(k=>esc(r[k])).join(','))].join('\n'));
});
app.use((err,req,res,next)=>{
 if(err instanceof z.ZodError)return res.status(400).json({error:err.issues.map(x=>x.message).join('; ')});
 if(err.code==='SQLITE_CONSTRAINT_UNIQUE')return res.status(409).json({error:'A unique value already exists (for example, email)'});
 if(err.code==='SQLITE_CONSTRAINT_FOREIGNKEY')return res.status(409).json({error:'Cannot delete this record because related orders/order items exist (foreign key restriction)'});
 if(err.code?.startsWith('SQLITE_CONSTRAINT'))return res.status(409).json({error:'Database constraint failed: '+err.message});
 console.error(err);
 res.status(err.status||400).json({error:err.message||'Request failed'});
});
const port=Number(process.env.PORT)||5000;
app.listen(port,()=>console.log(`Retail Analytics API http://localhost:${port}`));
