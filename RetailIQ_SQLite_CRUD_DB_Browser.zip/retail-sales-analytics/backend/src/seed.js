import {db} from './db.js';
let seed=421;const rnd=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
const choose=a=>a[Math.floor(rnd()*a.length)];
const names=['Aarav','Diya','Kabir','Ananya','Ishaan','Meera','Rohan','Sara','Vihaan','Aditi','Arjun','Nisha','Karan','Pooja','Neha','Riya','Yash','Simran'];
const surnames=['Sharma','Singh','Gupta','Kaur','Verma','Patel','Mehta','Kapoor'];
const regions=['North','South','East','West'];
const catalog=[
 ['Wireless Mouse','Electronics',799,480],['Bluetooth Speaker','Electronics',1999,1300],
 ['USB-C Cable','Electronics',349,140],['Laptop Stand','Electronics',1199,690],
 ['Notebook Set','Stationery',299,120],['Gel Pens','Stationery',149,65],
 ['Desk Organizer','Home',649,320],['Water Bottle','Home',499,230],
 ['Cotton T-Shirt','Fashion',699,340],['Backpack','Fashion',1599,920],
 ['LED Desk Lamp','Home',1299,720],['Power Bank','Electronics',2199,1480]
];
db.transaction(()=>{
 db.exec('DELETE FROM order_items;DELETE FROM orders;DELETE FROM products;DELETE FROM customers;');
 const ic=db.prepare('INSERT INTO customers(name,email,region,joined_at) VALUES(?,?,?,?)');
 for(let i=1;i<=120;i++){const name=choose(names)+' '+choose(surnames);ic.run(name,`customer${i}@example.com`,choose(regions),'2025-01-01');}
 const ip=db.prepare('INSERT INTO products(name,category,price,cost,stock) VALUES(?,?,?,?,?)');
 catalog.forEach(p=>ip.run(...p,Math.floor(rnd()*80)+8));
 const io=db.prepare('INSERT INTO orders(customer_id,order_date,status) VALUES(?,?,?)');
 const ii=db.prepare('INSERT INTO order_items(order_id,product_id,quantity,unit_price,unit_cost) VALUES(?,?,?,?,?)');
 const start=Date.UTC(2025,0,1),end=Date.UTC(2026,9,25);
 for(let i=0;i<850;i++){
  const date=new Date(start+Math.floor(rnd()*(end-start))).toISOString().slice(0,10);
  const status=rnd()<.055?'Cancelled':'Completed';
  const id=io.run(1+Math.floor(rnd()*105),date,status).lastInsertRowid;
  const count=1+Math.floor(rnd()*4);const used=new Set();
  for(let j=0;j<count;j++){let p=1+Math.floor(rnd()*catalog.length);if(used.has(p))continue;used.add(p);
   const row=catalog[p-1];ii.run(id,p,1+Math.floor(rnd()*4),row[2],row[3]);}
 }
})();
console.log('Seed complete: 120 customers, 12 products, 850 orders. Demo data is synthetic.');
